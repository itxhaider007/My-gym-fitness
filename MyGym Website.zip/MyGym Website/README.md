# MyGym Fitness website
This website contains frontend for Mygym website, and technologies used are 
* HTML    
 
* CSS

* JS(BOOTSTRAP)

<br>

#### Steps to Use:

---

- Download or clone the repository

```
git clone https://github.com/Ayushparikh-code/Web-dev-mini-projects.git
```

- Go to the directory
- Run the index.html file

## Output

![output1](https://github.com/jay-2000/Web-dev-mini-projects/blob/gymweb/MyGym%20Website/images/output/output1.png)

![output2](https://github.com/jay-2000/Web-dev-mini-projects/blob/gymweb/MyGym%20Website/images/output/output2.png)

![output2](https://github.com/jay-2000/Web-dev-mini-projects/blob/gymweb/MyGym%20Website/images/output/output3.png?raw=true)

